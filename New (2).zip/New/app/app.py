from enum import unique
from flask import Flask, flash,render_template,redirect,url_for,session,request
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import null
from sqlalchemy.exc import IntegrityError
from functools import wraps
import os

app=Flask(__name__)

app.secret_key="sanket"
app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:2610@localhost:3306/mysql'
app.config['SQLALCHEMY_TRACK_MODIFICATION']=False
app.permanent_session_lifetime=timedelta(minutes=5)

db=SQLAlchemy(app)


ad_1=False


class usersp(db.Model):
    _id=db.Column("id",db.Integer,primary_key=True,autoincrement=True)
    name=db.Column("name",db.String(100))
    email=db.Column("email",db.String(100),unique=True)
    DOB=db.Column("DOB",db.String(100))
    mobile=db.Column("mobile",db.String(20),unique=True)
    address=db.Column("address",db.String(200))
    password=db.Column("password",db.String(20))
    admin=db.Column("admin",db.String(10))

    def __init__(self,name,email,DOB,mobile,address,password,admin):
       self.name= name
       self.email= email
       self.DOB= DOB
       self.mobile= mobile
       self.address= address
       self.password= password
       self.admin=admin



# class admin_info(db.Model):
#     _id=db.Column("id",db.Integer,primary_key=True)
#     name=db.Column("name",db.String(100))
#     email=db.Column("email",db.String(100))
#     password=db.Column("password",db.String(20))

#     def __init__(self,name,email,password):
#        self.name= name
#        self.email= email
#        self.password= password

def login_required(fun):
    @wraps(fun)
    def decorated_function(*args, **kwargs):
        if session.get('email') is None:                 # or session.get('if_logged') is None:
            return redirect('/login')
        return fun(*args, **kwargs)
    return decorated_function



def ad_login_required(fun):
    @wraps(fun)
    def wrapper_function(*args,**kwargs):
        global ad_1
        if ad_1==False:                                   #if session.get('ad') is None:
            return "<h1>Admin Access Only....!</h1>"
        return fun(*args,**kwargs)
    return wrapper_function



@app.route("/",methods=["POST","GET"])
@app.route("/login",methods=["POST","GET"])
def login():
    if request.method=="POST":
        session.permanent=True
        email = request.form["nm"]
        password=request.form["pd"]
        
        session["email"]=email
        #session["password"]=password

        found_user=usersp.query.filter_by(email=email,password=password).first()
        if found_user:
            session["id"]=found_user._id
            return render_template("user.html",employee=found_user)  #redirect(url_for("user",employee=found_user))  #
        else:
            return render_template("cr.html")  #"<h2>Please sign up...!</h2>"
    else:
        if "email" in session:
            email=session["email"]
            found_user=usersp.query.filter_by(email=email).first()
            if found_user:
                return render_template("user.html",employee=found_user)
            else:
                return render_template("1.html")
        return render_template("1.html")



# @app.route("/user")
# def user():
#     if "user" in session:
#         return render_template("user.html")
#     else:
#         return "<h2>You are not logged in</h2>"



@app.route("/logout")
def logout():
    if "email" in session:
        email=session["email"]
    session.pop("name",None)
    session.pop("email",None)
    session.pop("id",None)
    global ad_1
    ad_1=False

    #session["ad"]=False

    return redirect(url_for("login"))  #render_template("1.html")#



@app.route("/signup" ,methods=["POST","GET"])
def signup():
    if request.method=="POST":
        session.permanent=True
        name = request.form["nm"]
        password=request.form["pd"]
        email=request.form["eml"]
        DOB = request.form["dt"]
        mobile=request.form["mb"]
        address=request.form["ad"]
        
        
        #session["password"]=password
        
        #session["DOB"]=DOB
        #session["mobile"]=mobile
        #session["address"]=address

        usr=usersp(name,email,DOB,mobile,address,password,admin="false")
        
        try:
            db.session.add(usr)
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash("Email/Phone Already Registered....!","info")
            return redirect(url_for("signup"))

        session["name"]=name
        session["email"]=email
        return redirect(url_for("login"))
    else:
        return render_template("signup.html")



@app.route("/update/<int:id>",methods=["POST","GET"])
@login_required
def update(id):
    if session["id"]==id :
        found_user=usersp.query.filter_by(_id=id).first()   #
        if request.method=="POST":
            #emp=user.query.get(id)

            found_user.name=request.form['nm']
            found_user.password=request.form['pd']
            found_user.email=request.form['eml']
            found_user.mobile=request.form['mb']
            found_user.address=request.form['ad']

            if request.form['dt']!=null:
                found_user.DOB=request.form['dt']


            db.session.commit()

            return redirect(url_for("login"))
            #return render_template("user.html",employee=found_user)
        else:
            return render_template("update.html",employee=found_user)
    else:
        return redirect(url_for("login"))





#--------------------------------ADMIN--------------------------------

@app.route("/ad_login",methods=["POST","GET"])
def ad_login():
    if request.method=="POST":
        email = request.form["eml"]
        password=request.form["pd"]

        found_user=usersp.query.filter_by(email=email,password=password,admin="true").first()
        if found_user:
            global ad_1
            ad_1=True
            user_info=usersp.query.all()
            return render_template("admin_ui.html",employees=user_info)  #redirect(url_for("user",employee=found_user))  #
        else:
            return "<h2>You are not admin...!</h2>"
    else:
        return render_template("admin_login.html")




@app.route("/ad_user/<int:id>",methods=["POST","GET"])
@ad_login_required
def ad_user(id):
    
    if request.method=='POST':
        ids=request.form.get("upd")
        #found_user=user.query.filter_by(_id=ids).first()
        return redirect(url_for("ad_update",id=ids))#render_template("update.html",employee=found_user)
    else:
        found_user=usersp.query.filter_by(_id=id).first()
        if found_user:
          return render_template("ad_user.html",employee=found_user)



@app.route("/ad_update/<int:id>",methods=["POST","GET"])
@ad_login_required
def ad_update(id):
        found_user=usersp.query.filter_by(_id=id).first()
        if request.method=="POST":
            #emp=user.query.get(id)

            found_user.name=request.form['nm']
            found_user.password=request.form['pd']
            found_user.email=request.form['eml']
            found_user.mobile=request.form['mb']
            found_user.address=request.form['ad']

            if request.form['dt']!=null:
                found_user.DOB=request.form['dt']


            db.session.commit()

            return redirect(url_for("ad_user",id=found_user._id))
            #return render_template("user.html",employee=found_user)
        else:
            return render_template("update.html",employee=found_user)



@app.route("/ad_delete",methods=['POST','GET'])
def ad_delete():
    if request.method=="POST":
        ids=request.form.get("dlt")
        found_user=usersp.query.filter_by(_id=ids).first()
        db.session.delete(found_user)
        db.session.commit()

        user_info=usersp.query.all()
        return render_template("admin_ui.html",employees=user_info)




if __name__=="__main__":
    db.create_all()
    #app.run(debug=True)
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)
